const { CPL, PL } = require("../models");

const cplController = {
  // Get all CPL with related data
  getAll: async (req, res) => {
    try {
      const cpls = await CPL.findAll({
        include: [
          {
            model: PL,
            as: "pl",
          },
        ],
      });

      res.status(200).json({
        success: true,
        message: "Data CPL berhasil diambil",
        data: cpls,
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: "Gagal mengambil data CPL",
        error: error.message,
      });
    }
  },

  // Create new CPL
  create: async (req, res) => {
    try {
      // Ambil userId dari request (misalnya sudah diset middleware auth)
      const userId = req.user?.id;

      if (!userId) {
        return res.status(400).json({
          success: false,
          message: "User ID tidak ditemukan",
        });
      }

      // Gabungkan req.body dengan userId
      const cpl = await CPL.create({
        ...req.body,
        userId,
      });

      res.status(201).json({
        success: true,
        message: "CPL berhasil dibuat",
        data: cpl,
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        message: "Gagal membuat CPL",
        error: error.message,
      });
    }
  },
};

module.exports = cplController;
