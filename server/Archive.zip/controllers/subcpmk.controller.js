const { SUBCPMK, CPMK, MK } = require("../models");

const subcpmkController = {
  // Get all SUBCPMK with related data
  getAll: async (req, res) => {
    try {
      const subcpmks = await SUBCPMK.findAll({
        include: [
          {
            model: CPMK,
            as: "cpmk",
          },
        ],
      });

      res.status(200).json({
        success: true,
        message: "Data Sub CPMK berhasil diambil",
        data: subcpmks,
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: "Gagal mengambil data Sub CPMK",
        error: error.message,
      });
    }
  },

  // Create new SUBCPMK
  create: async (req, res) => {
    try {
      // ambil userId dari middleware auth (misalnya req.user.id)
      const userId = req.user?.id;

      // gabungkan body dengan userId
      const subcpmk = await SUBCPMK.create({
        ...req.body,
        userId, // tambahkan di sini
      });

      res.status(201).json({
        success: true,
        message: "Sub CPMK berhasil dibuat",
        data: subcpmk,
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        message: "Gagal membuat Sub CPMK",
        error: error.message,
      });
    }
  },
};

module.exports = subcpmkController;
