const { PL, CPL } = require("../models");

const plController = {
  // Get all PL with related CPL
  getAll: async (req, res) => {
    try {
      const pls = await PL.findAll({
        include: [
          {
            model: CPL,
            as: "cpl",
          },
        ],
      });

      res.status(200).json({
        success: true,
        message: "Data PL berhasil diambil",
        data: pls,
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: "Gagal mengambil data PL",
        error: error.message,
      });
    }
  },

  // Create new PL
  create: async (req, res) => {
    try {
      // Ambil userId dari middleware auth atau body
      const userId = req.user.id;

      if (!userId) {
        return res.status(400).json({
          success: false,
          message: "User ID tidak ditemukan",
        });
      }

      // Simpan data dengan userId
      const pl = await PL.create({
        ...req.body,
        userId,
      });

      res.status(201).json({
        success: true,
        message: "PL berhasil dibuat",
        data: pl,
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        message: "Gagal membuat PL",
        error: error.message,
      });
    }
  },
};

module.exports = plController;
