const { MK, CPMK, PL, CPL, SUBCPMK } = require("../models");

const mkController = {
  // Get all MK with related data
  getAll: async (req, res) => {
    try {
      const mks = await MK.findAll({
        include: [
          {
            model: CPMK,
            as: "cpmk",
            include: [
              {
                model: CPL,
                as: "cpl",
                include: {
                  model: PL,
                  as: "pl",
                },
              },
              {
                model: SUBCPMK,
                as: "subcpmk",
              },
            ],
          },
        ],
      });

      res.status(200).json({
        success: true,
        message: "Data Mata Kuliah berhasil diambil",
        data: mks,
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: "Gagal mengambil data Mata Kuliah",
        error: error.message,
      });
    }
  },

  // Create new MK
  create: async (req, res) => {
    try {
      // Ambil userId dari middleware auth (JWT/session) atau dari body
      const userId = req.user?.id;

      if (!userId) {
        return res.status(400).json({
          success: false,
          message: "User ID tidak ditemukan",
        });
      }

      // Simpan Mata Kuliah dengan userId
      const mk = await MK.create({
        ...req.body,
        userId,
      });

      res.status(201).json({
        success: true,
        message: "Mata Kuliah berhasil dibuat",
        data: mk,
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        message: "Gagal membuat Mata Kuliah",
        error: error.message,
      });
    }
  },
};

module.exports = mkController;
