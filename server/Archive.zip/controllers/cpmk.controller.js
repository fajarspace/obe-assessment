const { CPMK, CPL, MK } = require("../models");

const cpmkController = {
  // Get all CPMK with related data
  getAll: async (req, res) => {
    try {
      const cpmks = await CPMK.findAll({
        include: [
          {
            model: CPL,
            as: "cpl",
          },
          {
            model: MK,
            as: "mk",
          },
        ],
      });

      res.status(200).json({
        success: true,
        message: "Data CPMK berhasil diambil",
        data: cpmks,
      });
    } catch (error) {
      res.status(500).json({
        success: false,
        message: "Gagal mengambil data CPMK",
        error: error.message,
      });
    }
  },

  // Create new CPMK
  create: async (req, res) => {
    try {
      // Misalnya userId sudah disimpan di req.user (setelah login & middleware auth)
      const userId = req.user?.id;

      const cpmk = await CPMK.create({
        ...req.body, // semua field dari body
        userId, // tambahkan userId
      });

      res.status(201).json({
        success: true,
        message: "CPMK berhasil dibuat",
        data: cpmk,
      });
    } catch (error) {
      res.status(400).json({
        success: false,
        message: "Gagal membuat CPMK",
        error: error.message,
      });
    }
  },
};

module.exports = cpmkController;
