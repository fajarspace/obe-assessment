const express = require("express");
const { isAuthenticated } = require("../middleware/auth");
const cpmkController = require("../controllers/cpmk.controller");
const router = express.Router();

router.get("/", isAuthenticated, cpmkController.getAll);
router.post("/", isAuthenticated, cpmkController.create);

module.exports = router;
