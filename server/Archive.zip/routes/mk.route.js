const express = require("express");
const { isAuthenticated } = require("../middleware/auth");
const mkController = require("../controllers/mk.controller");
const router = express.Router();

router.get("/", mkController.getAll);
router.post("/", isAuthenticated, mkController.create);

module.exports = router;
