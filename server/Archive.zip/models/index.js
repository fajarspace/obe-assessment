// models/index.js - File relasi yang sudah benar
const CPL = require("./cpl");
const CPMK = require("./cpmk");
const MK = require("./mk");
const PL = require("./pl");
const Profile = require("./profile");
const SUBCPMK = require("./subcpmk");
const Users = require("./users");

// User
Users.hasOne(Profile, { foreignKey: "userId", as: "profile" });
Profile.belongsTo(Users, { foreignKey: "userId", as: "user" });
Users.hasMany(PL, { foreignKey: "userId", as: "pl" });
PL.belongsTo(Users, { foreignKey: "userId", as: "user" });
Users.hasMany(CPL, { foreignKey: "userId", as: "cpl" });
CPL.belongsTo(Users, { foreignKey: "userId", as: "user" });
Users.hasMany(MK, { foreignKey: "userId", as: "mk" });
MK.belongsTo(Users, { foreignKey: "userId", as: "user" });
Users.hasMany(CPMK, { foreignKey: "userId", as: "cpmk" });
CPMK.belongsTo(Users, { foreignKey: "userId", as: "user" });
Users.hasMany(SUBCPMK, { foreignKey: "userId", as: "subcpmk" });
SUBCPMK.belongsTo(Users, { foreignKey: "userId", as: "user" });

// MK - CPMK (One-to-Many relationship)
PL.hasMany(CPL, { foreignKey: "plId", as: "cpl" });
CPL.belongsTo(PL, { foreignKey: "plId", as: "pl" });

// MK - CPMK (One-to-Many relationship)
// MK.hasMany(CPL, { foreignKey: "mkId", as: "cpl" });
// CPL.belongsTo(MK, { foreignKey: "mkId", as: "mk" });

// MK - CPMK (One-to-Many relationship)
MK.hasMany(CPMK, { foreignKey: "mkId", as: "cpmk" });
CPMK.belongsTo(MK, { foreignKey: "mkId", as: "mk" });

CPL.hasMany(CPMK, { foreignKey: "cplId", as: "cpmk" });
CPMK.belongsTo(CPL, { foreignKey: "cplId", as: "cpl" });

// CPMK - SUBCPMK (One-to-Many relationship)
CPMK.hasMany(SUBCPMK, { foreignKey: "cpmkId", as: "subcpmk" });
SUBCPMK.belongsTo(CPMK, { foreignKey: "cpmkId", as: "cpmk" });

module.exports = {
  PL,
  CPL,
  CPMK,
  SUBCPMK,
  MK,
  Users,
  Profile,
};
