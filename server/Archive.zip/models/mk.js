// models/mk.js
const { DataTypes } = require("sequelize");
const sequelize = require("../config/db");

const MK = sequelize.define(
  "MK",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      allowNull: false,
      autoIncrement: true,
    },
    kode: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
    },
    nama: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    sks: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 3,
      validate: {
        min: 1,
        max: 6,
      },
    },
    prodi: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    jenis: {
      type: DataTypes.ENUM("Wajib", "Pilihan", "MK Program Studi"),
      allowNull: false,
      defaultValue: "MK Program Studi",
    },
    userId: {
      type: DataTypes.UUID,
      allowNull: false,
    },
  },
  {
    freezeTableName: true,
    timestamps: false,
    tableName: "mk",
  }
);

module.exports = MK;
